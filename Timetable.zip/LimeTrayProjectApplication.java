package com.deloitte.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimeTrayProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimeTrayProjectApplication.class, args);
	}

}
